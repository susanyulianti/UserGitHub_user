package com.susan.usergithub.model

data class GitUserResponse(
    val items   : ArrayList<GitUser>
)
