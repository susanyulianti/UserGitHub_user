package com.susan.usergithub.model

data class GitUser (
    val login: String,
    val id: Int,
    val avatar_url: String
    )

